"use strict";

const crypto = require("node:crypto");
const fs = require("node:fs/promises");
const path = require("node:path");
const { promisify } = require("node:util");
const express = require("express");
const helmet = require("helmet");
const multer = require("multer");

const app = express();
const host = process.env.HOST || "127.0.0.1";
const port = Number(process.env.PORT || 4173);
const privateDir = path.resolve(process.env.DATA_DIR || path.join(__dirname, ".private"));
const uploadDir = path.join(privateDir, "uploads");
const bookingsFile = path.join(privateDir, "bookings.json");
const adminFile = path.join(privateDir, "admin.json");
const scrypt = promisify(crypto.scrypt);
const sessions = new Map();
const loginAttempts = new Map();
const bookingAttempts = new Map();
const sessionLifetime = 8 * 60 * 60 * 1000;
const maxPhotoBytes = 5 * 1024 * 1024;
let writeQueue = Promise.resolve();

const services = new Set([
  "Car / automotive video",
  "Real estate / property tour",
  "Restaurant / cafe / hotel",
  "Wedding / celebration",
  "Event / school coverage",
  "Brand / business film",
  "Product video",
  "Social media content",
  "Interview / documentary",
  "Editing / post-production",
  "Other"
]);

app.disable("x-powered-by");
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "https://unpkg.com"],
      styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
      fontSrc: ["'self'", "https://fonts.gstatic.com"],
      imgSrc: ["'self'", "data:", "blob:", "https:"],
      connectSrc: ["'self'"],
      formAction: ["'self'"],
      frameAncestors: ["'self'"],
      objectSrc: ["'none'"]
    }
  }
}));
app.use(express.json({ limit: "32kb" }));

const photoUpload = multer({
  storage: multer.memoryStorage(),
  limits: { files: 5, fileSize: maxPhotoBytes, fields: 8, fieldSize: 10000 },
  fileFilter: (_req, file, done) => {
    if (["image/jpeg", "image/png", "image/webp"].includes(file.mimetype)) return done(null, true);
    done(new Error("Use JPG, PNG, or WEBP images."));
  }
});

function clientIsSameOrigin(req, res, next) {
  const origin = req.get("origin");
  if (origin && new URL(origin).host !== req.get("host")) {
    return res.status(403).json({ error: "Cross-origin request denied." });
  }
  next();
}

function localClient(req) {
  const address = req.socket.remoteAddress || "";
  return address === "127.0.0.1" || address === "::1" || address === "::ffff:127.0.0.1";
}

function tooMany(map, key, limit, interval) {
  const now = Date.now();
  let entry = map.get(key);
  if (!entry || entry.until <= now) entry = { count: 0, until: now + interval };
  entry.count += 1;
  map.set(key, entry);
  return entry.count > limit;
}

function safeText(value, maxLength) {
  return typeof value === "string" ? value.trim().slice(0, maxLength) : "";
}

function validEmail(value) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
}

function photoExtension(buffer) {
  if (buffer.length >= 8 && buffer.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]))) return "png";
  if (buffer.length >= 3 && buffer[0] === 255 && buffer[1] === 216 && buffer[2] === 255) return "jpg";
  if (buffer.length >= 12 && buffer.toString("ascii", 0, 4) === "RIFF" && buffer.toString("ascii", 8, 12) === "WEBP") return "webp";
  return "";
}

async function readBookings() {
  try {
    const bookings = JSON.parse(await fs.readFile(bookingsFile, "utf8"));
    return bookings.map((booking) => ({
      ...booking,
      status: ({ new: "pending", done: "completed" })[booking.status] || booking.status,
      amountQuoted: Number.isFinite(Number(booking.amountQuoted)) ? Number(booking.amountQuoted) : 0,
      amountPaid: Number.isFinite(Number(booking.amountPaid)) ? Number(booking.amountPaid) : 0
    }));
  } catch (error) {
    if (error.code === "ENOENT") return [];
    throw error;
  }
}

function updateBookings(change) {
  const operation = writeQueue.then(async () => {
    const bookings = await readBookings();
    const result = change(bookings);
    const temporaryFile = bookingsFile + ".tmp";
    await fs.writeFile(temporaryFile, JSON.stringify(bookings, null, 2), { mode: 0o600 });
    await fs.rename(temporaryFile, bookingsFile);
    return result;
  });
  writeQueue = operation.catch(() => {});
  return operation;
}

async function readAdmin() {
  try {
    return JSON.parse(await fs.readFile(adminFile, "utf8"));
  } catch (error) {
    if (error.code === "ENOENT") return null;
    throw error;
  }
}

function cookieToken(req) {
  const cookies = (req.headers.cookie || "").split(";");
  const cookie = cookies.find((part) => part.trim().startsWith("land_admin="));
  return cookie ? decodeURIComponent(cookie.trim().slice("land_admin=".length)) : "";
}

function setAdminCookie(res, token, maxAge) {
  const secure = process.env.NODE_ENV === "production" ? "; Secure" : "";
  res.setHeader("Set-Cookie", `land_admin=${encodeURIComponent(token)}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${maxAge}${secure}`);
}

function requireAdmin(req, res, next) {
  const token = cookieToken(req);
  const session = sessions.get(token);
  if (!session || session.expires <= Date.now()) {
    if (token) sessions.delete(token);
    return res.status(401).json({ error: "Please log in to the admin panel." });
  }
  next();
}

async function startSession(res) {
  const token = crypto.randomBytes(32).toString("base64url");
  sessions.set(token, { expires: Date.now() + sessionLifetime });
  setAdminCookie(res, token, Math.floor(sessionLifetime / 1000));
}

app.get("/api/admin/status", async (_req, res, next) => {
  try {
    res.json({ setupRequired: !(await readAdmin()) });
  } catch (error) {
    next(error);
  }
});

app.post("/api/admin/setup", clientIsSameOrigin, async (req, res, next) => {
  try {
    if (!localClient(req)) return res.status(403).json({ error: "Initial setup is available only on this computer." });
    if (await readAdmin()) return res.status(409).json({ error: "Admin account already exists. Please log in." });
    const username = safeText(req.body.username, 60);
    const password = typeof req.body.password === "string" ? req.body.password : "";
    if (username.length < 3 || password.length < 12 || password.length > 200) {
      return res.status(400).json({ error: "Choose a username (3+ characters) and password (12+ characters)." });
    }
    const salt = crypto.randomBytes(16);
    const hash = await scrypt(password, salt, 64);
    await fs.writeFile(adminFile, JSON.stringify({ username, salt: salt.toString("hex"), hash: hash.toString("hex") }), { mode: 0o600, flag: "wx" });
    await startSession(res);
    res.status(201).json({ ok: true });
  } catch (error) {
    if (error.code === "EEXIST") return res.status(409).json({ error: "Admin account already exists. Please log in." });
    next(error);
  }
});

app.post("/api/admin/login", clientIsSameOrigin, async (req, res, next) => {
  try {
    const key = req.ip;
    if (tooMany(loginAttempts, key, 5, 15 * 60 * 1000)) return res.status(429).json({ error: "Too many login attempts. Try again in 15 minutes." });
    const admin = await readAdmin();
    if (!admin) return res.status(409).json({ error: "Create the admin login on first use." });
    const username = safeText(req.body.username, 60);
    const password = typeof req.body.password === "string" ? req.body.password : "";
    const candidate = await scrypt(password, Buffer.from(admin.salt, "hex"), 64);
    const matches = crypto.timingSafeEqual(candidate, Buffer.from(admin.hash, "hex"));
    if (username !== admin.username || !matches) return res.status(401).json({ error: "Username or password is incorrect." });
    loginAttempts.delete(key);
    await startSession(res);
    res.json({ ok: true });
  } catch (error) {
    next(error);
  }
});

app.get("/api/admin/session", (req, res) => {
  const session = sessions.get(cookieToken(req));
  if (session && session.expires > Date.now()) return res.json({ authenticated: true });
  res.json({ authenticated: false });
});

app.post("/api/admin/logout", clientIsSameOrigin, requireAdmin, (req, res) => {
  sessions.delete(cookieToken(req));
  setAdminCookie(res, "", 0);
  res.json({ ok: true });
});

app.post("/api/bookings", clientIsSameOrigin, photoUpload.array("photos", 5), async (req, res, next) => {
  const storedFiles = [];
  try {
    if (tooMany(bookingAttempts, req.ip, 8, 60 * 60 * 1000)) return res.status(429).json({ error: "Please wait before submitting another request." });
    const fields = {
      service: safeText(req.body.service, 120),
      name: safeText(req.body.name, 120),
      city: safeText(req.body.city, 120),
      phone: safeText(req.body.phone, 60),
      email: safeText(req.body.email, 180),
      details: safeText(req.body.details, 3000)
    };
    if (!services.has(fields.service)) return res.status(400).json({ error: "Choose a valid project type." });
    if (fields.name.length < 2 || !fields.city || fields.phone.length < 5 || !validEmail(fields.email)) {
      return res.status(400).json({ error: "Please complete your name, city, phone, and a valid email address." });
    }

    const files = (req.files || []).map((file) => ({ file, extension: photoExtension(file.buffer) }));
    if (files.some((item) => !item.extension)) return res.status(400).json({ error: "One or more photos are not valid JPG, PNG, or WEBP images." });
    const photos = [];
    for (const item of files) {
      const file = item.file;
      const extension = item.extension;
      const storedName = `${crypto.randomUUID()}.${extension}`;
      await fs.writeFile(path.join(uploadDir, storedName), file.buffer, { flag: "wx", mode: 0o600 });
      storedFiles.push(storedName);
      photos.push({ name: safeText(path.basename(file.originalname), 180), storedName });
    }

    const booking = {
      id: crypto.randomUUID(),
      createdAt: new Date().toISOString(),
      ...fields,
      status: "pending",
      amountQuoted: 0,
      amountPaid: 0,
      photos
    };
    await updateBookings((bookings) => bookings.unshift(booking));
    res.status(201).json({ ok: true, id: booking.id });
  } catch (error) {
    await Promise.all(storedFiles.map((name) => fs.unlink(path.join(uploadDir, name)).catch(() => {})));
    next(error);
  }
});

app.get("/api/admin/bookings", requireAdmin, async (_req, res, next) => {
  try {
    res.json(await readBookings());
  } catch (error) {
    next(error);
  }
});

app.patch("/api/admin/bookings/:id", clientIsSameOrigin, requireAdmin, async (req, res, next) => {
  try {
    const status = safeText(req.body.status, 20);
    const amountQuoted = Number(req.body.amountQuoted);
    const amountPaid = Number(req.body.amountPaid);
    if (!["pending", "contacted", "confirmed", "completed"].includes(status) || !Number.isFinite(amountQuoted) || amountQuoted < 0 || amountQuoted > 100000000 || !Number.isFinite(amountPaid) || amountPaid < 0 || amountPaid > 100000000) {
      return res.status(400).json({ error: "Choose a valid status, quote, and payment amount." });
    }
    const booking = await updateBookings((bookings) => {
      const match = bookings.find((item) => item.id === req.params.id);
      if (!match) return false;
      match.status = status;
      match.amountQuoted = amountQuoted;
      match.amountPaid = amountPaid;
      match.updatedAt = new Date().toISOString();
      return true;
    });
    if (!booking) return res.status(404).json({ error: "Booking not found." });
    res.json({ ok: true });
  } catch (error) {
    next(error);
  }
});

app.get("/api/admin/bookings/:id/photos/:filename", requireAdmin, async (req, res, next) => {
  try {
    if (!/^[a-f0-9-]+\.(jpg|png|webp)$/.test(req.params.filename)) return res.sendStatus(404);
    const bookings = await readBookings();
    const booking = bookings.find((item) => item.id === req.params.id);
    const photo = booking && booking.photos.find((item) => item.storedName === req.params.filename);
    if (!photo) return res.sendStatus(404);
    res.setHeader("Cache-Control", "private, no-store");
    res.setHeader("Content-Disposition", "inline");
    res.sendFile(path.join(uploadDir, photo.storedName));
  } catch (error) {
    next(error);
  }
});

app.use((req, res, next) => {
  const blocked = new Set(["node_modules", "server.js", "package.json", "package-lock.json", "README.md"]);
  if (blocked.has(req.path.split("/")[1])) return res.sendStatus(404);
  next();
});
app.use(express.static(__dirname, { dotfiles: "deny", index: "index.html", extensions: ["html"] }));
app.use((error, _req, res, _next) => {
  const status = error instanceof multer.MulterError ? 400 : 500;
  const message = status === 400 ? error.message : "The request could not be completed.";
  if (status === 500) console.error(error);
  res.status(status).json({ error: message });
});

async function start() {
  await fs.mkdir(uploadDir, { recursive: true, mode: 0o700 });
  await app.listen(port, host);
  console.log(`Portfolio running at http://${host}:${port}`);
  console.log("Booking data and uploaded photos are stored in the private .private folder.");
}

start().catch((error) => {
  console.error("Could not start the portfolio server.", error);
  process.exitCode = 1;
});